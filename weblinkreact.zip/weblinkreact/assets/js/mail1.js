// port 587
// port 25 sll 3576a195-919e-48c7-8ed8-468febf84879
//4cbf0cb7-5533-450b-b18c-ba82c2e8436a
// goolge gmail port 25 sll ok 68f677b0-880c-497a-8989-1a0416c52eb0
// youtb optimal key oyther fbf31702-bb7f-4a4e-9c1c-4ccf17ee777f
// web oen mail cb1106c0-5a8e-4c86-82a3-e2ff887ded77

//web.net ***** cb1106c0-5a8e-4c86-82a3-e2ff887ded77
//we 2013 slave both 3f608d66-7018-4ed1-a97e-fd1dfd5284db


// SecureToken:"fbf31702-bb7f-4a4e-9c1c-4ccf17ee777f",To: 'optimalweb09@gmail.com',  From: "demooptimalweb@gmail.com",
function send(){
			
			Email.send({
    SecureToken : "3f608d66-7018-4ed1-a97e-fd1dfd5284db",
    To : 'weblinkservices2013@gmail.com',
    From : "weblinkservices2013@gmail.com",
    Subject : "Contact form",
    Body : "Name : Rahul <br> Email: rahul@gmail.com <br> Mob: 76444125652"

}).then(
  message => alert(message)
);
}